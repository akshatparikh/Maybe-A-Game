package com.example.yash.maybeagame;

/**
 * Created by Yash on 14-03-2018.
 */

public class Time {

    long time = 0;
    boolean hasStop = false;

}
